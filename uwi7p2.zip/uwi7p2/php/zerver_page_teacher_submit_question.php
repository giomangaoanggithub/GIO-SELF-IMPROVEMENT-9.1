<?php
//CHECKED
include 'zerver_entrance.php';

session_start();

error_reporting(0);

$hps = $_POST["hps"];
$due = $_POST["due_date"];
$email = $_SESSION["curr_email_user"];
$question = $_POST["question"];
$type = $_POST["type"];
$items = $_POST["items"];
$room = $_POST["room"];
if($items == "" || $type == "response"){
  $items = "<!@#%GRADES$%^><!@#CORRECT$%^><!@#INCORRECT$%^><!@#ENUMERATE$%^>";
} else {
  $items = explode(",", $items);
  $hold = "<!@#%GRADES$%^><!@#CORRECT$%^><!@#INCORRECT$%^><!@#ENUMERATE$%^>";
  for($i = 0; $i < count($items); $i++){
    $items[$i] = "<*&*>".$items[$i];
    $hold .= $items[$i];
  }
  $items = $hold;
}


try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "INSERT INTO created_questions (question, HPS, time_of_issue, due_date, owner_teacher, classroom_id, publish, checking_param, type_question)
  VALUES ('$question', '$hps', current_timestamp(), '$due', '$email', '$room', '1', '$items', '$type')";
  // use exec() because no results are returned
  $conn->exec($sql);
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
?>